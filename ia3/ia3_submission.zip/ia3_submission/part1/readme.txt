1. Required packages:
    Python 3
    Pandas
    Numpy
    Matplotlib
    csv

2. To run the code, enter the virtual environment, and run python3 ./part1.py
3. The file part1_randomized.py shows the effect of data randomization on the perceptron. It can be run using python3 ./part1_randomized.py