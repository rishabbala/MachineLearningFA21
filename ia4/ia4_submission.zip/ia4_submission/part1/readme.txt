1. Required packages:
    Python 3
    Pandas
    Numpy
    Matplotlib
    csv

2. To run the code, enter the virtual environment, and run python3 ./part1.py
