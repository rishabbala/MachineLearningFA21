1. Download the python script and data together

2. Set up the virtual environment to include:
    a. Numpy
    b. Matplotlib
    c. Pandas

3. Run the script as "python3 ia0.py". To get the plot for the impact of the encoded_date format on price run "python3 plots.py"